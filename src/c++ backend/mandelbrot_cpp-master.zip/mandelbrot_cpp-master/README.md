# mandelbrot_cpp
Draw the mandelbrot-set in C++
# Tutorial:
https://medium.com/farouk-ounanes-home-on-the-internet/mandelbrot-set-in-c-from-scratch-c7ad6a1bf2d9

![alt text](https://github.com/ChinksofLight/mandelbrot_cpp/blob/master/image.jpeg)
